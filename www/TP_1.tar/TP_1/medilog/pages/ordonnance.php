<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>MEDILOG - Ordonnance</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="cadre">
            <div class="row align-items-center">
                <div class="col-md-4 text-center text-md-start">
                    <img src="../images/medicaments2.jpg" alt="Logo Médilog" class="logo-entete">
                </div>
                <div class="col-md-8 text-center">
                    <i class="fa fa-user-md fa-2x"></i>
                    <h1>APPLICATION<br>MEDILOG</h1>
                </div>
            </div>
            <div class="text-center mt-3">
                <h2><i class="fa fa-id-card"></i> Création d'une ordonnance <i class="fa fa-id-card"></i></h2>
            </div>
        </div>

        <div class="row g-0">
            <div class="col-md-6">
                <div class="cadre h-100">
                    <h2>Recherche</h2>
                    <form action="ordonnance.html" method="post">
                        <div class="mb-2">
                            <label for="designation" class="form-label text-center d-block">Désignation à rechercher :</label>
                            <input type="text" class="form-control" id="designation" placeholder="Tapez un mot à rechercher">
                        </div>
                        <div class="mb-2">
                            <label for="type" class="form-label text-center d-block">Type de médicament :</label>
                            <select class="form-select" id="type">
                                <option selected>Collyre</option>
                                <option>Comprimé</option>
                                <option>Effervescent</option>
                                <option>Gellule</option>
                                <option>Pommade</option>
                            </select>
                        </div>
                        <div class="mb-2">
                            <label for="labo" class="form-label text-center d-block">Laboratoire :</label>
                            <select class="form-select" id="labo">
                                <option selected>MERK</option>
                                <option>SANDOZ</option>
                                <option>UPSA</option>
                            </select>
                        </div>
                        <div class="text-center">
                            <input type="submit" class="btn btn-light border w-100" value="Envoyer">
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="cadre h-100">
                    <h2>Ordonnance</h2>
                    <div class="table-responsive">
                        <table class="table table-bordered text-center align-middle">
                            <thead>
                                <tr class="table-light">
                                    <th>Désignation</th>
                                    <th>Présentation</th>
                                    <th>Laboratoire</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Aspirine 500mg</td>
                                    <td>Effervescent</td>
                                    <td>UPSA</td>
                                </tr>
                                <tr>
                                    <td>Doliprane 1000mg</td>
                                    <td>Comprimé</td>
                                    <td>SANDOZ</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="cadre">
            <h2>Résultat de la recherche</h2>
            <div class="table-responsive">
                <table class="table table-bordered text-center align-middle">
                    <thead>
                        <tr class="table-light">
                            <th>Désignation</th>
                            <th>Présentation</th>
                            <th>Laboratoire</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Aspirine 500mg</td>
                            <td>Effervescent</td>
                            <td>UPSA</td>
                        </tr>
                        <tr>
                            <td>Aspirine 1000mg</td>
                            <td>Comprimé</td>
                            <td>MERK</td>
                        </tr>
                        <tr>
                            <td>Doliprane 1000mg</td>
                            <td>Comprimé</td>
                            <td>SANDOZ</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="row g-0">
            <div class="col-md-9">
                <div class="cadre text-center h-100">
                    <div class="menu-titre mb-2">
                        <i class="fa fa-sitemap"></i> Menu :
                    </div>
                    <div class="d-flex flex-column flex-lg-row justify-content-center align-items-center">
                        <a href="../index.php" class="nav-link"><i class="fa fa-home"></i> Accueil</a>
                        <a href="recherche.php" class="nav-link"><i class="fa fa-search"></i> Recherche d'un médicament</a>
                        <a href="ordonnance.php" class="nav-link"><i class="fa fa-id-card"></i> Création ordonnance</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="cadre text-center h-100">
                    <div class="fw-bold"><i class="fa fa-spinner"></i> Réalisé par</div>
                    <img src="../images/LogoIut.png" alt="IUT de Rodez" class="logo-iut">
                </div>
            </div>
        </div>
    </div>
</body>
</html>